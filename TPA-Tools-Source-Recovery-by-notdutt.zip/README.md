# TPA Tools source recovery

Recovered from the uploaded `tpa tools.jar.disabled`.

## What is included

- Original `fabric.mod.json` and manifest/resources.
- Every original `.class` file.
- `javap -c -p -l -s` output for every class, preserving the exact compiled
  method signatures, descriptors, control flow instructions, and line tables.
- A Gradle-style source tree and simple reconstructed source for the addon
  entrypoint/shared state.
- Placeholders for complex classes that point to their exact bytecode reference.

## Important limitation

A compiled JAR does **not** contain the original Java source. Comments, some local
variable names, formatting, and source-level constructs are lost during compilation.
This package therefore does not pretend that invented Java is the original source.

For the highest-quality Java reconstruction, open the original JAR in IntelliJ
(built-in FernFlower decompiler), CFR, or Vineflower and copy the decompiled output
into the matching files under `src/main/java`.

The uploaded mod identifies itself as TPA Tools 1.6.1 for Minecraft 1.21.11,
Java 21, and Meteor Client, with `me.tpaburst.TPABurstAddon` as the Meteor entrypoint.
